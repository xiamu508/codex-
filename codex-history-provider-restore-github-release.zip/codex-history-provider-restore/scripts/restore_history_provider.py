#!/usr/bin/env python3
"""Restore Codex history visibility after provider/account switching.

Dry-run is the default. Use --apply only after reviewing the planned changes.
The script changes only model_provider labels in session JSONL first lines and
the matching provider column in the threads table in state_5.sqlite.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import shutil
import sqlite3
import tempfile
from pathlib import Path


SESSION_DIR_NAMES = ("sessions", "archived_sessions")


def expand(path: str) -> Path:
    return Path(path).expanduser().resolve()


def iter_jsonl_files(codex_home: Path) -> list[Path]:
    files: list[Path] = []
    for name in SESSION_DIR_NAMES:
        root = codex_home / name
        if root.exists():
            files.extend(sorted(root.rglob("*.jsonl")))
    return files


def read_lines(path: Path) -> list[str]:
    try:
        return path.read_text(encoding="utf-8").splitlines()
    except UnicodeDecodeError:
        return path.read_text(encoding="utf-8-sig").splitlines()


def read_first_json(path: Path) -> tuple[dict | None, list[str]]:
    lines = read_lines(path)
    if not lines:
        return None, lines
    try:
        return json.loads(lines[0]), lines
    except json.JSONDecodeError:
        return None, lines


def payload_from_meta(meta: dict | None) -> dict | None:
    if not isinstance(meta, dict):
        return None
    payload = meta.get("payload")
    return payload if isinstance(payload, dict) else None


def provider_from_file(path: Path) -> str | None:
    meta, _ = read_first_json(path)
    payload = payload_from_meta(meta)
    value = payload.get("model_provider") if payload else None
    return value if isinstance(value, str) else None


def session_id_from_file(path: Path) -> str:
    meta, _ = read_first_json(path)
    payload = payload_from_meta(meta)
    if payload:
        value = payload.get("id")
        if isinstance(value, str) and value:
            return value
    stem = path.stem
    return stem.rsplit("-", 1)[-1] if "-" in stem else stem


def find_thread_by_text(codex_home: Path, needle: str) -> tuple[str, Path]:
    matches: list[Path] = []
    for path in iter_jsonl_files(codex_home):
        try:
            if needle in path.read_text(encoding="utf-8", errors="ignore"):
                matches.append(path)
        except OSError:
            continue
    if not matches:
        raise SystemExit(f"No session JSONL contains search text: {needle!r}")
    matches.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    chosen = matches[0]
    return session_id_from_file(chosen), chosen


def find_thread_path(codex_home: Path, thread_id: str) -> Path | None:
    for path in iter_jsonl_files(codex_home):
        if session_id_from_file(path) == thread_id:
            return path
    return None


def current_provider_from_sqlite(db_path: Path, thread_id: str) -> str:
    conn = sqlite3.connect(str(db_path))
    try:
        row = conn.execute(
            "SELECT model_provider FROM threads WHERE id = ?", (thread_id,)
        ).fetchone()
    finally:
        conn.close()
    if not row or not row[0]:
        raise SystemExit(f"Current thread not found in SQLite: {thread_id}")
    return str(row[0])


def sqlite_counts(db_path: Path) -> list[tuple[str, int]]:
    conn = sqlite3.connect(str(db_path))
    try:
        rows = conn.execute(
            "SELECT model_provider, COUNT(*) FROM threads "
            "GROUP BY model_provider ORDER BY model_provider"
        ).fetchall()
    finally:
        conn.close()
    return [(str(provider), int(count)) for provider, count in rows]


def jsonl_counts(codex_home: Path) -> dict[str, int]:
    counts: dict[str, int] = {}
    for path in iter_jsonl_files(codex_home):
        provider = provider_from_file(path) or "<missing>"
        counts[provider] = counts.get(provider, 0) + 1
    return dict(sorted(counts.items()))


def make_backup_root(base: Path, target_provider: str) -> Path:
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    root = base / f"codex-provider-to-{target_provider}-{stamp}"
    (root / "jsonl").mkdir(parents=True, exist_ok=False)
    (root / "state").mkdir(parents=True, exist_ok=True)
    return root


def write_provider(path: Path, target_provider: str) -> bool:
    meta, lines = read_first_json(path)
    payload = payload_from_meta(meta)
    if not payload:
        return False
    if payload.get("model_provider") == target_provider:
        return False
    payload["model_provider"] = target_provider
    first = json.dumps(meta, ensure_ascii=False, separators=(",", ":"))
    text = "\n".join([first, *lines[1:]])
    if lines:
        text += "\n"

    fd, tmp_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent)
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as tmp:
            tmp.write(text)
        os.replace(tmp_name, path)
    except Exception:
        try:
            os.unlink(tmp_name)
        except FileNotFoundError:
            pass
        raise
    return True


def update_sqlite(db_path: Path, target_provider: str, ids: set[str]) -> int:
    if not ids:
        return 0
    conn = sqlite3.connect(str(db_path))
    try:
        changed = 0
        with conn:
            for thread_id in sorted(ids):
                cur = conn.execute(
                    "UPDATE threads SET model_provider = ? "
                    "WHERE id = ? AND model_provider <> ?",
                    (target_provider, thread_id, target_provider),
                )
                changed += cur.rowcount
        return changed
    finally:
        conn.close()


def default_backup_base() -> str:
    outputs = Path.cwd() / "outputs"
    if outputs.exists():
        return str(outputs / "codex-history-backups")
    return str(Path.cwd() / "codex-history-backups")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--codex-home", default="~/.codex")
    parser.add_argument("--current-thread-id")
    parser.add_argument(
        "--search-text",
        help="Unique text from the current chat; used to find the thread id.",
    )
    parser.add_argument("--backup-base", default=default_backup_base())
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    codex_home = expand(args.codex_home)
    db_path = codex_home / "state_5.sqlite"
    if not db_path.exists():
        raise SystemExit(f"Missing SQLite index: {db_path}")

    located_path = None
    thread_id = args.current_thread_id
    if not thread_id:
        if not args.search_text:
            raise SystemExit("Pass --current-thread-id or --search-text.")
        thread_id, located_path = find_thread_by_text(codex_home, args.search_text)
    else:
        located_path = find_thread_path(codex_home, thread_id)

    target_provider = current_provider_from_sqlite(db_path, thread_id)
    files = iter_jsonl_files(codex_home)
    files_to_change = [
        path for path in files if provider_from_file(path) not in (None, target_provider)
    ]
    ids_to_change = {session_id_from_file(path) for path in files_to_change}

    report = {
        "mode": "apply" if args.apply else "dry-run",
        "current_thread_id": thread_id,
        "current_thread_path": str(located_path) if located_path else None,
        "target_provider": target_provider,
        "before_jsonl_provider_counts": jsonl_counts(codex_home),
        "before_sqlite_provider_counts": sqlite_counts(db_path),
        "planned_jsonl_changes": len(files_to_change),
        "planned_thread_ids": len(ids_to_change),
        "backup_base": str(expand(args.backup_base)),
    }
    if not args.apply:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0

    backup_root = make_backup_root(expand(args.backup_base), target_provider)
    copied = 0
    for path in files_to_change:
        rel = path.relative_to(codex_home)
        dest = backup_root / "jsonl" / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dest)
        copied += 1
    shutil.copy2(db_path, backup_root / "state" / "state_5.sqlite")
    (backup_root / "meta.json").write_text(
        json.dumps(
            {
                "current_thread_id": thread_id,
                "current_thread_path": str(located_path) if located_path else None,
                "target_provider": target_provider,
                "jsonl_files": [str(path) for path in files_to_change],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    changed_files = sum(1 for path in files_to_change if write_provider(path, target_provider))
    changed_rows = update_sqlite(db_path, target_provider, ids_to_change)
    report.update(
        {
            "backup_root": str(backup_root),
            "backup_jsonl_files": copied,
            "changed_jsonl_files": changed_files,
            "changed_sqlite_rows": changed_rows,
            "after_jsonl_provider_counts": jsonl_counts(codex_home),
            "after_sqlite_provider_counts": sqlite_counts(db_path),
        }
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
